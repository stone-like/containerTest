#!/bin/sh

/usr/libexec/nm-initrd-generator -- $(getcmdline)
